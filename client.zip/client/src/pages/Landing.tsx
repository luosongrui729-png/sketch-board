import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Sparkles, Users, Palette } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

// Dummy data for demonstration
const DEMO_CANVASES = [
  { code: "ABC123", name: "Design Meeting", users: 3, lastActive: "2 min ago" },
  { code: "XYZ789", name: "Team Brainstorm", users: 5, lastActive: "5 min ago" },
  { code: "DEF456", name: "Project Sketch", users: 2, lastActive: "15 min ago" },
];

const DEMO_USERS = [
  { name: "Sarah Chen", color: "#FF6B6B", tool: "Pen" },
  { name: "Alex Rivera", color: "#4ECDC4", tool: "Shape" },
  { name: "Jordan Kim", color: "#FFE66D", tool: "Text" },
  { name: "Maya Patel", color: "#95E1D3", tool: "Pen" },
  { name: "Chris Wong", color: "#F38181", tool: "Image" },
];

function generateCanvasCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export default function Landing() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [userName, setUserName] = useState("");
  const [canvasCode, setCanvasCode] = useState("");
  const [activeTab, setActiveTab] = useState<"new" | "join">("new");

  const createCanvasMutation = useMutation({
    mutationFn: async (name: string) => {
      const code = generateCanvasCode();
      const response = await apiRequest("POST", "/api/canvases", {
        name: `${name}'s Canvas`,
        code,
        canvasData: JSON.stringify({ version: "6.0.0", objects: [] }),
      });
      const data = await response.json();
      return { ...data, code };
    },
    onSuccess: (data) => {
      toast({
        title: "Canvas Created!",
        description: `Your canvas code is: ${data.code}`,
      });
      setLocation(`/${data.code}`);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create canvas. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartDrawing = () => {
    if (!userName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter your name to get started.",
        variant: "destructive",
      });
      return;
    }
    // Store username for collaboration
    localStorage.setItem("whiteboard_username", userName);
    createCanvasMutation.mutate(userName);
  };

  const handleJoinCanvas = async () => {
    if (!canvasCode.trim()) {
      toast({
        title: "Code Required",
        description: "Please enter a canvas code to join.",
        variant: "destructive",
      });
      return;
    }

    if (!userName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter your name to join the canvas.",
        variant: "destructive",
      });
      return;
    }

    const code = canvasCode.toUpperCase();
    
    // Store username for collaboration
    localStorage.setItem("whiteboard_username", userName);
    
    // Verify canvas exists before navigating
    try {
      const res = await fetch(`/api/canvases/code/${code}`, {
        credentials: "include",
      });
      
      if (!res.ok) {
        toast({
          title: "Canvas Not Found",
          description: `No canvas found with code: ${code}`,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Joining Canvas!",
        description: `Connecting to canvas: ${code}`,
      });
      setLocation(`/${code}`);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to verify canvas. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-indigo-600 via-purple-600 to-blue-500">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-pink-300/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-yellow-300/10 rounded-full blur-3xl animate-pulse delay-500"></div>
        {/* Stars effect */}
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full animate-pulse"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Palette className="w-12 h-12 text-white" />
            <h1 className="text-6xl font-bold text-white">DrawSpace</h1>
          </div>
          <p className="text-xl text-white/90 mb-2">Your Digital Creative Workspace</p>
          <p className="text-white/70 flex items-center justify-center gap-2">
            <Users className="w-4 h-4" />
            <span>{DEMO_USERS.length} users creating right now</span>
          </p>
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* New User Card */}
            <Card
              className={`border-2 transition-all cursor-pointer ${
                activeTab === "new"
                  ? "border-white shadow-2xl scale-105"
                  : "border-white/30 hover:border-white/50"
              }`}
              onClick={() => setActiveTab("new")}
              data-testid="card-new-user"
            >
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-purple-600" />
                  <CardTitle className="text-2xl">Start Drawing</CardTitle>
                </div>
                <CardDescription>Create your own canvas and invite others</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="userName" data-testid="label-username">
                    What's your name?
                  </Label>
                  <Input
                    id="userName"
                    placeholder="Enter your name"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleStartDrawing()}
                    disabled={createCanvasMutation.isPending}
                    className="text-lg"
                    data-testid="input-username"
                  />
                </div>
                <Button
                  onClick={handleStartDrawing}
                  disabled={createCanvasMutation.isPending}
                  className="w-full text-lg h-12"
                  data-testid="button-start-drawing"
                >
                  {createCanvasMutation.isPending ? "Creating..." : "Get My Canvas Code"}
                </Button>
                <p className="text-sm text-muted-foreground text-center">
                  You'll receive a unique 6-character code to share
                </p>
              </CardContent>
            </Card>

            {/* Join Canvas Card */}
            <Card
              className={`border-2 transition-all cursor-pointer ${
                activeTab === "join"
                  ? "border-white shadow-2xl scale-105"
                  : "border-white/30 hover:border-white/50"
              }`}
              onClick={() => setActiveTab("join")}
              data-testid="card-join-canvas"
            >
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Users className="w-6 h-6 text-blue-600" />
                  <CardTitle className="text-2xl">Join Canvas</CardTitle>
                </div>
                <CardDescription>Enter a code to collaborate with others</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="join-user-name" data-testid="label-join-username">
                    Your Name
                  </Label>
                  <Input
                    id="join-user-name"
                    placeholder="Enter your name"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="text-lg"
                    data-testid="input-join-username"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="canvasCode" data-testid="label-canvas-code">
                    Canvas Code
                  </Label>
                  <Input
                    id="canvasCode"
                    placeholder="Enter 6-character code"
                    value={canvasCode}
                    onChange={(e) => setCanvasCode(e.target.value.toUpperCase())}
                    onKeyDown={(e) => e.key === "Enter" && handleJoinCanvas()}
                    maxLength={6}
                    className="text-lg font-mono tracking-wider"
                    data-testid="input-canvas-code"
                  />
                </div>
                <Button
                  onClick={handleJoinCanvas}
                  className="w-full text-lg h-12"
                  variant="secondary"
                  data-testid="button-join-canvas"
                >
                  Join Collaboration
                </Button>
                <p className="text-sm text-muted-foreground text-center">
                  Ask your teammate for their canvas code
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Active Canvases Demo */}
          <Card className="bg-white/95 backdrop-blur" data-testid="card-active-canvases">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Active Canvases (Demo)
              </CardTitle>
              <CardDescription>See what others are working on</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {DEMO_CANVASES.map((canvas) => (
                  <div
                    key={canvas.code}
                    className="p-4 rounded-lg bg-gradient-to-br from-purple-50 to-blue-50 border border-purple-200 hover-elevate cursor-pointer"
                    onClick={() => setCanvasCode(canvas.code)}
                    data-testid={`demo-canvas-${canvas.code}`}
                  >
                    <div className="font-mono text-lg font-bold text-purple-600 mb-1">
                      {canvas.code}
                    </div>
                    <div className="text-sm font-medium mb-2">{canvas.name}</div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {canvas.users} users
                      </span>
                      <span>{canvas.lastActive}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Online Users Demo */}
          <Card className="mt-8 bg-white/95 backdrop-blur" data-testid="card-online-users">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Currently Drawing (Demo)
              </CardTitle>
              <CardDescription>Users actively creating right now</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-3">
                {DEMO_USERS.map((user, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-2 px-4 py-2 rounded-full border bg-white"
                    data-testid={`demo-user-${index}`}
                  >
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: user.color }}
                    />
                    <span className="font-medium">{user.name}</span>
                    <span className="text-xs text-muted-foreground">• {user.tool}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-white/70">
          <p className="text-sm">
            Real-time collaboration • Unlimited canvas • Auto-save • Export to PNG/PDF
          </p>
        </div>
      </div>
    </div>
  );
}
