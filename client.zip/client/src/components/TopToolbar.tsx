import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import {
  MousePointer2,
  Pen,
  Eraser,
  Type,
  Square,
  Circle,
  Triangle,
  Minus,
  MoveRight,
  Pentagon,
  Hexagon,
  Star,
  Image as ImageIcon,
  Download,
  FileText,
  Plus,
  ChevronDown,
  Undo2,
  Redo2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Share2,
  Pencil,
  Trash2,
  Users,
  Wifi,
} from "lucide-react";
import { cn } from "@/lib/utils";

const PRESET_COLORS = [
  "#000000", "#FFFFFF", "#FF0000", "#00FF00", "#0000FF",
  "#FFFF00", "#FF00FF", "#00FFFF", "#FFA500", "#800080",
  "#FFC0CB", "#A52A2A", "#808080", "#00FF7F", "#4169E1",
  "#FFD700", "#8B4513", "#2E8B57", "#DC143C", "#1E90FF",
];

const SHAPES = [
  { id: "rectangle", label: "Rectangle", icon: Square },
  { id: "circle", label: "Circle", icon: Circle },
  { id: "triangle", label: "Triangle", icon: Triangle },
  { id: "line", label: "Line", icon: Minus },
  { id: "arrow", label: "Arrow", icon: MoveRight },
  { id: "pentagon", label: "Pentagon", icon: Pentagon },
  { id: "hexagon", label: "Hexagon", icon: Hexagon },
  { id: "star", label: "Star", icon: Star },
];

interface TopToolbarProps {
  activeTool: string;
  onToolChange: (tool: string) => void;
  strokeColor: string;
  fillColor: string;
  onStrokeColorChange: (color: string) => void;
  onFillColorChange: (color: string) => void;
  penSize: number;
  onPenSizeChange: (size: number) => void;
  penOpacity: number;
  onPenOpacityChange: (opacity: number) => void;
  penType: string;
  onPenTypeChange: (type: string) => void;
  zoom: number;
  onZoomChange: (zoom: number) => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  canvases: any[];
  currentCanvasId: string;
  onCanvasSelect: (id: string) => void;
  onCanvasCreate: () => void;
  onCanvasRename: (id: string, name: string) => void;
  onCanvasDelete: (id: string) => void;
  onExport: () => void;
  onShare: () => void;
  onImageInsert: () => void;
  isConnected: boolean;
  userCount: number;
}

export function TopToolbar(props: TopToolbarProps) {
  const currentCanvas = props.canvases.find(c => c.id === props.currentCanvasId);

  return (
    <div className="h-14 bg-[#2C2D30] border-b border-[#3E3F42] flex items-center gap-2 px-3 overflow-x-auto" data-testid="toolbar-top">
      {/* Canvas Selector */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="gap-2 text-white hover:bg-white/10" data-testid="button-canvas-menu">
            <FileText className="w-4 h-4" />
            <span className="text-sm max-w-32 truncate">{currentCanvas?.name || "Canvas"}</span>
            <ChevronDown className="w-4 h-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-80 bg-[#2C2D30] border-[#3E3F42]">
          <div className="p-2">
            <Button onClick={props.onCanvasCreate} className="w-full gap-2" size="sm" data-testid="button-create-canvas">
              <Plus className="w-4 h-4" />
              New Canvas
            </Button>
          </div>
          <DropdownMenuSeparator className="bg-[#3E3F42]" />
          <div className="max-h-96 overflow-y-auto p-2 space-y-2">
            {props.canvases.map((canvas) => (
              <div
                key={canvas.id}
                className={cn(
                  "p-2 rounded cursor-pointer group hover:bg-white/5",
                  canvas.id === props.currentCanvasId && "bg-white/10"
                )}
                onClick={() => props.onCanvasSelect(canvas.id)}
                data-testid={`canvas-item-${canvas.id}`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm text-white truncate">{canvas.name}</span>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100">
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-white hover:bg-white/10">
                      <Pencil className="w-3 h-3" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-red-400 hover:bg-white/10">
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <div className="text-xs text-gray-400 font-mono mt-1">{canvas.code}</div>
              </div>
            ))}
          </div>
        </DropdownMenuContent>
      </DropdownMenu>

      <Separator orientation="vertical" className="h-8 bg-[#3E3F42]" />

      {/* Tools */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => props.onToolChange("select")}
        className={cn("text-white hover:bg-white/10", props.activeTool === "select" && "bg-white/20")}
        data-testid="button-tool-select"
      >
        <MousePointer2 className="w-5 h-5" />
      </Button>

      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => props.onToolChange("pen")}
            className={cn("text-white hover:bg-white/10", props.activeTool === "pen" && "bg-white/20")}
            data-testid="button-tool-pen"
          >
            <Pen className="w-5 h-5" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64 bg-[#2C2D30] border-[#3E3F42]">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-xs text-white">Brush Size</Label>
              <Slider
                value={[props.penSize]}
                onValueChange={([size]) => props.onPenSizeChange(size)}
                min={2}
                max={20}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-400">
                <span>2px</span>
                <span>{props.penSize}px</span>
                <span>20px</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-xs text-white">Opacity</Label>
              <Slider
                value={[props.penOpacity]}
                onValueChange={([opacity]) => props.onPenOpacityChange(opacity)}
                min={0}
                max={100}
                step={1}
              />
              <div className="flex justify-between text-xs text-gray-400">
                <span>0%</span>
                <span>{props.penOpacity}%</span>
                <span>100%</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-xs text-white">Type</Label>
              <div className="grid grid-cols-3 gap-1">
                {["Standard", "Marker", "Highlighter"].map((type) => (
                  <Button
                    key={type}
                    variant="outline"
                    size="sm"
                    onClick={() => props.onPenTypeChange(type.toLowerCase())}
                    className={cn(
                      "text-xs text-white border-[#3E3F42] hover:bg-white/10",
                      props.penType === type.toLowerCase() && "bg-white/20"
                    )}
                  >
                    {type}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      <Button
        variant="ghost"
        size="icon"
        onClick={() => props.onToolChange("eraser")}
        className={cn("text-white hover:bg-white/10", props.activeTool === "eraser" && "bg-white/20")}
        data-testid="button-tool-eraser"
      >
        <Eraser className="w-5 h-5" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        onClick={() => props.onToolChange("text")}
        className={cn("text-white hover:bg-white/10", props.activeTool === "text" && "bg-white/20")}
        data-testid="button-tool-text"
      >
        <Type className="w-5 h-5" />
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className="gap-1 text-white hover:bg-white/10"
            data-testid="button-tool-shapes"
          >
            <Square className="w-4 h-4" />
            <span className="text-xs">Shapes</span>
            <ChevronDown className="w-3 h-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-48 bg-[#2C2D30] border-[#3E3F42]">
          {SHAPES.map((shape) => (
            <DropdownMenuItem
              key={shape.id}
              onClick={() => props.onToolChange(`shape-${shape.id}`)}
              className="text-white hover:bg-white/10 cursor-pointer"
            >
              <shape.icon className="w-4 h-4 mr-2" />
              {shape.label}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <Separator orientation="vertical" className="h-8 bg-[#3E3F42]" />

      {/* Color Pickers */}
      <ColorPickerButton
        label="Stroke"
        color={props.strokeColor}
        onChange={props.onStrokeColorChange}
      />
      <ColorPickerButton
        label="Fill"
        color={props.fillColor}
        onChange={props.onFillColorChange}
      />

      <Separator orientation="vertical" className="h-8 bg-[#3E3F42]" />

      {/* Zoom */}
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => props.onZoomChange(Math.max(10, props.zoom - 10))}
          className="text-white hover:bg-white/10"
          data-testid="button-zoom-out"
        >
          <ZoomOut className="w-4 h-4" />
        </Button>
        <span className="text-xs text-white font-mono min-w-12 text-center">{props.zoom}%</span>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => props.onZoomChange(Math.min(400, props.zoom + 10))}
          className="text-white hover:bg-white/10"
          data-testid="button-zoom-in"
        >
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => props.onZoomChange(100)}
          className="text-white hover:bg-white/10"
          data-testid="button-zoom-reset"
        >
          <Maximize2 className="w-4 h-4" />
        </Button>
      </div>

      <Separator orientation="vertical" className="h-8 bg-[#3E3F42]" />

      {/* Undo/Redo */}
      <Button
        variant="ghost"
        size="icon"
        onClick={props.onUndo}
        disabled={!props.canUndo}
        className="text-white hover:bg-white/10 disabled:opacity-30"
        data-testid="button-undo"
      >
        <Undo2 className="w-4 h-4" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={props.onRedo}
        disabled={!props.canRedo}
        className="text-white hover:bg-white/10 disabled:opacity-30"
        data-testid="button-redo"
      >
        <Redo2 className="w-4 h-4" />
      </Button>

      <Separator orientation="vertical" className="h-8 bg-[#3E3F42]" />

      {/* Actions */}
      <Button
        variant="ghost"
        size="icon"
        onClick={props.onImageInsert}
        className="text-white hover:bg-white/10"
        data-testid="button-insert-image"
      >
        <ImageIcon className="w-4 h-4" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={props.onExport}
        className="text-white hover:bg-white/10"
        data-testid="button-export"
      >
        <Download className="w-4 h-4" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={props.onShare}
        className="text-white hover:bg-white/10"
        data-testid="button-share"
      >
        <Share2 className="w-4 h-4" />
      </Button>

      <div className="flex-1" />

      {/* Status */}
      <div className="flex items-center gap-2">
        <div className={cn(
          "flex items-center gap-1.5 px-2 py-1 rounded text-xs",
          props.isConnected ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
        )}>
          <Wifi className="w-3 h-3" />
          <span>{props.isConnected ? "Connected" : "Disconnected"}</span>
        </div>
        {props.userCount > 1 && (
          <div className="flex items-center gap-1.5 px-2 py-1 rounded text-xs bg-blue-500/20 text-blue-400">
            <Users className="w-3 h-3" />
            <span>{props.userCount}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function ColorPickerButton({ label, color, onChange }: { label: string; color: string; onChange: (color: string) => void }) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" className="gap-2 text-white hover:bg-white/10">
          <div className="w-4 h-4 rounded border border-white/20" style={{ backgroundColor: color }} />
          <span className="text-xs">{label}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 bg-[#2C2D30] border-[#3E3F42]">
        <div className="space-y-3">
          <Label className="text-xs text-white">{label} Color</Label>
          <div className="grid grid-cols-5 gap-2">
            {PRESET_COLORS.map((presetColor) => (
              <button
                key={presetColor}
                className={cn(
                  "w-10 h-10 rounded border-2 hover:scale-110 transition-transform",
                  color === presetColor ? "border-blue-400" : "border-transparent"
                )}
                style={{ backgroundColor: presetColor }}
                onClick={() => onChange(presetColor)}
              />
            ))}
          </div>
          <div className="space-y-2">
            <Label className="text-xs text-white">Custom</Label>
            <div className="flex gap-2">
              <Input
                type="color"
                value={color}
                onChange={(e) => onChange(e.target.value)}
                className="h-10 w-16 p-1 cursor-pointer bg-transparent border-[#3E3F42]"
              />
              <Input
                type="text"
                value={color}
                onChange={(e) => onChange(e.target.value)}
                className="h-10 flex-1 font-mono text-sm bg-transparent border-[#3E3F42] text-white"
              />
            </div>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
