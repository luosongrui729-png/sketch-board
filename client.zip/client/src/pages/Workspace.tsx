import { useState, useRef, useCallback, useEffect } from "react";
import { LeftSidebar } from "@/components/LeftSidebar";
import { RightSidebar } from "@/components/RightSidebar";
import { CanvasArea } from "@/components/CanvasArea";
import { Canvas, FabricImage } from "fabric";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Canvas as CanvasType, InsertCanvas } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useCollaboration } from "@/hooks/useCollaboration";
import jsPDF from "jspdf";

function generateCanvasCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export default function Workspace() {
  const { toast } = useToast();
  const [activeTool, setActiveTool] = useState("select");
  const [strokeColor, setStrokeColor] = useState("#000000");
  const [fillColor, setFillColor] = useState("#FFFFFF");
  const [textColor, setTextColor] = useState("#000000");
  const [penSize, setPenSize] = useState(5);
  const [penOpacity, setPenOpacity] = useState(100);
  const [penType, setPenType] = useState("standard");
  const [eraserSize, setEraserSize] = useState(15);
  const [textSize, setTextSize] = useState(16);
  const [textAlign, setTextAlign] = useState("left");
  const [zoom, setZoom] = useState(100);
  const [showGrid, setShowGrid] = useState(false);
  const [currentCanvasId, setCurrentCanvasId] = useState<string | null>(null);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  
  const canvasRef = useRef<Canvas | null>(null);
  const undoStack = useRef<string[]>([]);
  const redoStack = useRef<string[]>([]);
  const isUndoRedoRef = useRef(false);
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const clipboardRef = useRef<any>(null);
  const lastLoadedCanvasData = useRef<string | null>(null); // Track last loaded data to prevent unnecessary reloads

  // Real-time collaboration
  const collaboration = useCollaboration(currentCanvasId, canvasRef.current, activeTool);

  // Fetch canvases from API
  const { data: canvases = [], isLoading: canvasesLoading } = useQuery<CanvasType[]>({
    queryKey: ["/api/canvases"],
  });

  // Set initial canvas when data loads or create one if none exist
  useEffect(() => {
    if (!canvasesLoading) {
      if (canvases.length === 0 && !createCanvasMutation.isPending) {
        // Create a default canvas if none exist
        createCanvasMutation.mutate({
          name: "My First Canvas",
          code: generateCanvasCode(),
          canvasData: {},
        });
      } else if (!currentCanvasId && canvases.length > 0) {
        setCurrentCanvasId(canvases[0].id);
      }
    }
  }, [canvases, currentCanvasId, canvasesLoading]);

  // Create canvas mutation with retry logic for duplicate codes
  const createCanvasMutation = useMutation({
    mutationFn: async (data: InsertCanvas) => {
      let attempts = 0;
      const maxAttempts = 5;
      
      while (attempts < maxAttempts) {
        try {
          // Check if code exists in current canvases
          const codeExists = canvases.some((c) => c.code === data.code);
          if (codeExists) {
            data.code = generateCanvasCode();
            attempts++;
            continue;
          }
          
          const response = await apiRequest("POST", "/api/canvases", data);
          return await response.json();
        } catch (error: any) {
          // If code conflict, retry with new code
          if (error?.message?.includes("unique") || error?.status === 409) {
            data.code = generateCanvasCode();
            attempts++;
            continue;
          }
          throw error;
        }
      }
      
      throw new Error("Failed to generate unique canvas code");
    },
    onSuccess: (newCanvas) => {
      queryClient.invalidateQueries({ queryKey: ["/api/canvases"] });
      setCurrentCanvasId(newCanvas.id);
      toast({
        title: "Canvas created",
        description: `Share code: ${newCanvas.code}`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create canvas",
        variant: "destructive",
      });
    },
  });

  // Update canvas mutation
  const updateCanvasMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertCanvas> }) => {
      const response = await apiRequest("PATCH", `/api/canvases/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/canvases"] });
    },
    onError: (error, variables) => {
      console.error("Canvas update failed:", error, variables);
      // Only show toast for user-initiated actions (not auto-save)
      if (variables.data.name !== undefined) {
        toast({
          title: "Error",
          description: "Failed to update canvas",
          variant: "destructive",
        });
      }
    },
  });

  // Delete canvas mutation
  const deleteCanvasMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/canvases/${id}`);
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: ["/api/canvases"] });
      toast({
        title: "Canvas deleted",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete canvas",
        variant: "destructive",
      });
    },
  });

  const handleCanvasCreate = () => {
    createCanvasMutation.mutate({
      name: "Untitled Canvas",
      code: generateCanvasCode(),
      canvasData: {},
    });
  };

  const handleCanvasRename = (id: string, newName: string) => {
    updateCanvasMutation.mutate({ id, data: { name: newName } });
  };

  const handleCanvasDelete = (id: string) => {
    // Clear currentCanvasId if deleting active canvas to stop auto-save
    if (currentCanvasId === id) {
      const filtered = canvases.filter((c) => c.id !== id);
      if (filtered.length > 0) {
        setCurrentCanvasId(filtered[0].id);
      } else {
        setCurrentCanvasId(null);
      }
    }
    deleteCanvasMutation.mutate(id);
  };

  const handleExport = (format: string, options: any) => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const { area = "full", resolution: resolutionStr = "1x", background = "white" } = options;
    
    // Parse resolution from string format (1x, 2x, 4x) to number
    const resolution = parseInt(resolutionStr.replace('x', '')) || 1;

    let dataURL: string;
    let exportWidth: number;
    let exportHeight: number;

    if (area === "selection") {
      const activeObject = canvas.getActiveObject();
      if (!activeObject) {
        toast({
          title: "No selection",
          description: "Please select an object to export",
          variant: "destructive",
        });
        return;
      }

      // Export only the selected object(s)
      const bounds = activeObject.getBoundingRect();
      exportWidth = bounds.width;
      exportHeight = bounds.height;

      dataURL = canvas.toDataURL({
        format: "png",
        quality: 1,
        multiplier: resolution,
        left: bounds.left,
        top: bounds.top,
        width: bounds.width,
        height: bounds.height,
      });
    } else if (area === "visible") {
      // Export visible viewport area
      const vpt = canvas.viewportTransform || [1, 0, 0, 1, 0, 0];
      const zoom = canvas.getZoom();
      const canvasWidth = canvas.width || 800;
      const canvasHeight = canvas.height || 600;

      // Calculate visible area coordinates
      const left = -vpt[4] / zoom;
      const top = -vpt[5] / zoom;
      exportWidth = canvasWidth / zoom;
      exportHeight = canvasHeight / zoom;

      dataURL = canvas.toDataURL({
        format: "png",
        quality: 1,
        multiplier: resolution,
        left: left,
        top: top,
        width: exportWidth,
        height: exportHeight,
        enableRetinaScaling: false,
      });
    } else {
      // Export full canvas
      exportWidth = canvas.width || 800;
      exportHeight = canvas.height || 600;

      dataURL = canvas.toDataURL({
        format: "png",
        quality: 1,
        multiplier: resolution,
        enableRetinaScaling: false,
      });
    }

    if (format === "png") {
      // Create download link
      const link = document.createElement("a");
      link.download = `canvas-${currentCanvas?.code || "export"}.png`;
      link.href = dataURL;
      link.click();

      toast({
        title: "Canvas exported",
        description: `PNG saved at ${resolution}x resolution`,
      });
    } else if (format === "pdf") {
      // Create PDF using jsPDF
      const pdf = new jsPDF({
        orientation: exportWidth > exportHeight ? "landscape" : "portrait",
        unit: "px",
        format: [exportWidth * resolution, exportHeight * resolution],
      });

      // Add the canvas image to PDF
      pdf.addImage(
        dataURL,
        "PNG",
        0,
        0,
        exportWidth * resolution,
        exportHeight * resolution
      );

      // Download PDF
      pdf.save(`canvas-${currentCanvas?.code || "export"}.pdf`);

      toast({
        title: "Canvas exported",
        description: "PDF saved successfully",
      });
    }
  };

  const handleShare = (code?: string) => {
    if (code) {
      console.log("Join canvas with code:", code);
    } else {
      console.log("Share current canvas");
    }
  };

  const saveStateRef = useRef<(() => void) | null>(null);

  // Auto-save canvas data every 5 seconds with thumbnail
  useEffect(() => {
    if (!currentCanvasId || !canvasRef.current) return;

    const autoSave = () => {
      if (canvasRef.current) {
        const canvasData = canvasRef.current.toJSON();
        
        // Generate thumbnail (200x150 max)
        const thumbnail = canvasRef.current.toDataURL({
          format: 'png',
          quality: 0.6,
          multiplier: 0.2,
          enableRetinaScaling: false,
        });
        
        updateCanvasMutation.mutate({
          id: currentCanvasId,
          data: { canvasData, thumbnail },
        });
      }
    };

    // Start auto-save timer
    autoSaveTimerRef.current = setInterval(autoSave, 5000);

    return () => {
      if (autoSaveTimerRef.current) {
        clearInterval(autoSaveTimerRef.current);
        autoSaveTimerRef.current = null;
      }
    };
  }, [currentCanvasId]);

  // Load canvas data when switching canvases
  useEffect(() => {
    if (!currentCanvasId || !canvasRef.current || canvasesLoading) return;

    const currentCanvas = canvases.find((c) => c.id === currentCanvasId);
    if (currentCanvas) {
      const canvasData = currentCanvas.canvasData && typeof currentCanvas.canvasData === 'object' 
        && Object.keys(currentCanvas.canvasData).length > 0
        ? currentCanvas.canvasData
        : { objects: [] };
      
      // CRITICAL FIX: Only reload if data actually changed
      // This prevents flickering when React Query refetches the same data
      const canvasDataString = JSON.stringify(canvasData);
      if (lastLoadedCanvasData.current === canvasDataString) {
        return; // Data hasn't changed, don't reload
      }
      
      lastLoadedCanvasData.current = canvasDataString;
      
      canvasRef.current.loadFromJSON(canvasData).then(() => {
        // CRITICAL FIX: Restore globalCompositeOperation for eraser strokes
        // Fabric.js doesn't automatically restore this property from JSON
        const canvas = canvasRef.current!;
        const objects = canvas.getObjects();
        
        // Check the original JSON data for globalCompositeOperation values
        const data = canvasData as any;
        if (data.objects && Array.isArray(data.objects)) {
          data.objects.forEach((objData: any, index: number) => {
            if (objData.globalCompositeOperation && objects[index]) {
              (objects[index] as any).globalCompositeOperation = objData.globalCompositeOperation;
            }
          });
        }
        
        canvas.renderAll();
        // Reset undo/redo stacks for the new canvas
        const initialState = JSON.stringify(canvas.toJSON());
        undoStack.current = [initialState];
        redoStack.current = [];
        setCanUndo(false);
        setCanRedo(false);
      });
    }
  }, [currentCanvasId, canvases, canvasesLoading]);

  const handleCanvasReady = useCallback((canvas: Canvas) => {
    canvasRef.current = canvas;
    
    // Save initial state
    const initialState = JSON.stringify(canvas.toJSON());
    undoStack.current = [initialState];
    
    // Track changes for undo/redo and collaboration
    const saveState = () => {
      if (isUndoRedoRef.current) return;
      
      const currentState = JSON.stringify(canvas.toJSON());
      undoStack.current.push(currentState);
      redoStack.current = [];
      setCanUndo(undoStack.current.length > 1);
      setCanRedo(false);
    };
    
    saveStateRef.current = saveState;
    
    // CRITICAL FIX: Restore globalCompositeOperation property after canvas loads from JSON
    // This ensures eraser strokes work correctly after save/load or undo/redo
    canvas.on('object:added', (e) => {
      const obj = e.target as any;
      if (obj && obj.globalCompositeOperation) {
        // Property is already set, just ensure toObject includes it
        if (!obj._originalToObject) {
          obj._originalToObject = obj.toObject;
          obj.toObject = function(this: any) {
            return Object.assign(obj._originalToObject.call(this), {
              globalCompositeOperation: this.globalCompositeOperation
            });
          };
        }
      }
    });
    
    canvas.on("object:added", (e) => {
      saveState();
      if (e.target && collaboration.assignObjectId && collaboration.sendCanvasUpdate) {
        // Assign stable ID to the object
        collaboration.assignObjectId(e.target);
        const jsonData = e.target.toJSON();
        jsonData.objectId = (e.target as any).objectId;
        collaboration.sendCanvasUpdate("object-added", jsonData);
      }
    });
    
    canvas.on("object:modified", (e) => {
      saveState();
      if (e.target && collaboration.sendObjectModified) {
        const jsonData = e.target.toJSON();
        jsonData.objectId = (e.target as any).objectId;
        collaboration.sendObjectModified(jsonData);
      }
    });
    
    canvas.on("object:removed", (e) => {
      saveState();
      if (e.target && collaboration.sendObjectRemoved) {
        const target = e.target as any;
        collaboration.sendObjectRemoved(target.objectId);
      }
    });
  }, [collaboration]);
  
  const handleShapeComplete = useCallback(() => {
    if (saveStateRef.current) {
      saveStateRef.current();
    }
  }, []);
  
  // Comprehensive keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in an input field
      const target = e.target as HTMLElement;
      const isEditingText = 
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.contentEditable === "true" ||
        target.getAttribute("contenteditable") === "true";
      
      // Don't intercept if Fabric IText is being edited
      const isFabricTextEditing = canvasRef.current?.getActiveObject()?.get("isEditing");
      
      if (isEditingText || isFabricTextEditing) return;
      
      const canvas = canvasRef.current;
      if (!canvas) return;
      
      // Ctrl+Z: Undo
      if ((e.ctrlKey || e.metaKey) && e.key === "z" && !e.shiftKey) {
        e.preventDefault();
        handleUndo();
      } 
      // Ctrl+Y or Ctrl+Shift+Z: Redo
      else if ((e.ctrlKey || e.metaKey) && (e.key === "y" || (e.key === "z" && e.shiftKey))) {
        e.preventDefault();
        handleRedo();
      }
      // Ctrl+C: Copy
      else if ((e.ctrlKey || e.metaKey) && e.key === "c") {
        const activeObject = canvas.getActiveObject();
        if (activeObject) {
          e.preventDefault();
          activeObject.clone().then((cloned: any) => {
            clipboardRef.current = cloned;
          });
          toast({
            title: "Copied",
            description: "Object copied to clipboard",
          });
        }
      }
      // Ctrl+V: Paste
      else if ((e.ctrlKey || e.metaKey) && e.key === "v") {
        if (clipboardRef.current) {
          e.preventDefault();
          clipboardRef.current.clone().then((cloned: any) => {
            canvas.discardActiveObject();
            cloned.set({
              left: cloned.left + 10,
              top: cloned.top + 10,
              evented: true,
            });
            if (cloned.type === 'activeSelection') {
              cloned.canvas = canvas;
              cloned.forEachObject((obj: any) => {
                canvas.add(obj);
              });
              cloned.setCoords();
            } else {
              canvas.add(cloned);
            }
            clipboardRef.current.top += 10;
            clipboardRef.current.left += 10;
            canvas.setActiveObject(cloned);
            canvas.requestRenderAll();
          });
        }
      }
      // Delete or Backspace: Delete selected object(s)
      else if (e.key === "Delete" || e.key === "Backspace") {
        const activeObject = canvas.getActiveObject();
        if (activeObject) {
          e.preventDefault();
          // Handle multi-selection (ActiveSelection)
          if (activeObject.type === 'activeSelection') {
            const selection = activeObject as any;
            selection.forEachObject((obj: any) => {
              canvas.remove(obj);
            });
            canvas.discardActiveObject();
          } else {
            // Single object deletion
            canvas.remove(activeObject);
          }
          canvas.requestRenderAll();
        }
      }
      // Ctrl+A: Select all
      else if ((e.ctrlKey || e.metaKey) && e.key === "a") {
        e.preventDefault();
        canvas.discardActiveObject();
        const sel = new (canvas.constructor as any).ActiveSelection(canvas.getObjects(), {
          canvas: canvas,
        });
        canvas.setActiveObject(sel);
        canvas.requestRenderAll();
      }
    };

    const handleWheel = (e: WheelEvent) => {
      // Ctrl+Scroll: Zoom
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        const delta = e.deltaY;
        const newZoom = Math.max(10, Math.min(400, zoom + (delta > 0 ? -10 : 10)));
        setZoom(newZoom);
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("wheel", handleWheel, { passive: false });
    
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("wheel", handleWheel);
    };
  }, [canUndo, canRedo, zoom, toast]);

  const handleImageInsert = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file && canvasRef.current) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const imgUrl = event.target?.result as string;
          FabricImage.fromURL(imgUrl).then((img) => {
            const canvas = canvasRef.current!;
            img.scaleToWidth(200);
            
            // Position the image at the center of the current viewport
            const vpt = canvas.viewportTransform!;
            const zoom = canvas.getZoom();
            const canvasWidth = canvas.getWidth();
            const canvasHeight = canvas.getHeight();
            
            // Calculate the center of the visible area
            const centerX = (-vpt[4] + canvasWidth / 2) / zoom;
            const centerY = (-vpt[5] + canvasHeight / 2) / zoom;
            
            // Position the image at the center
            img.set({
              left: centerX - (img.width! * img.scaleX!) / 2,
              top: centerY - (img.height! * img.scaleY!) / 2,
            });
            
            canvas.add(img);
            canvas.setActiveObject(img); // Select the newly added image
            canvas.renderAll();
            
            // Add to undo stack
            if (!isUndoRedoRef.current) {
              const canvasState = JSON.stringify(canvas.toJSON());
              undoStack.current.push(canvasState);
              redoStack.current = [];
            }
            
            // Notify collaboration system
            if (collaboration.assignObjectId && collaboration.sendCanvasUpdate) {
              collaboration.assignObjectId(img);
              const jsonData = img.toJSON();
              collaboration.sendCanvasUpdate("object-added", jsonData);
            }
          }).catch((error) => {
            console.error("Error creating FabricImage:", error);
          });
        };
        reader.onerror = (error) => {
          console.error("FileReader error:", error);
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleUndo = () => {
    if (undoStack.current.length > 1 && canvasRef.current) {
      isUndoRedoRef.current = true;
      const currentState = undoStack.current.pop()!;
      redoStack.current.push(currentState);
      
      const previousState = undoStack.current[undoStack.current.length - 1];
      const stateData = JSON.parse(previousState);
      
      canvasRef.current.loadFromJSON(stateData).then(() => {
        // CRITICAL FIX: Restore globalCompositeOperation for eraser strokes
        const canvas = canvasRef.current!;
        const objects = canvas.getObjects();
        
        if (stateData.objects && Array.isArray(stateData.objects)) {
          stateData.objects.forEach((objData: any, index: number) => {
            if (objData.globalCompositeOperation && objects[index]) {
              (objects[index] as any).globalCompositeOperation = objData.globalCompositeOperation;
            }
          });
        }
        
        canvas.renderAll();
        isUndoRedoRef.current = false;
        setCanUndo(undoStack.current.length > 1);
        setCanRedo(redoStack.current.length > 0);
      });
    }
  };

  const handleRedo = () => {
    if (redoStack.current.length > 0 && canvasRef.current) {
      isUndoRedoRef.current = true;
      const nextState = redoStack.current.pop()!;
      undoStack.current.push(nextState);
      
      const stateData = JSON.parse(nextState);
      
      canvasRef.current.loadFromJSON(stateData).then(() => {
        // CRITICAL FIX: Restore globalCompositeOperation for eraser strokes
        const canvas = canvasRef.current!;
        const objects = canvas.getObjects();
        
        if (stateData.objects && Array.isArray(stateData.objects)) {
          stateData.objects.forEach((objData: any, index: number) => {
            if (objData.globalCompositeOperation && objects[index]) {
              (objects[index] as any).globalCompositeOperation = objData.globalCompositeOperation;
            }
          });
        }
        
        canvas.renderAll();
        isUndoRedoRef.current = false;
        setCanUndo(undoStack.current.length > 1);
        setCanRedo(redoStack.current.length > 0);
      });
    }
  };

  const currentCanvas = canvases.find((c) => c.id === currentCanvasId);

  return (
    <div className="h-screen flex bg-background overflow-hidden">
      <LeftSidebar
        activeTool={activeTool}
        onToolChange={setActiveTool}
        strokeColor={strokeColor}
        fillColor={fillColor}
        textColor={textColor}
        onStrokeColorChange={setStrokeColor}
        onFillColorChange={setFillColor}
        onTextColorChange={setTextColor}
        penSize={penSize}
        onPenSizeChange={setPenSize}
        penOpacity={penOpacity}
        onPenOpacityChange={setPenOpacity}
        penType={penType}
        onPenTypeChange={setPenType}
        eraserSize={eraserSize}
        onEraserSizeChange={setEraserSize}
        textSize={textSize}
        onTextSizeChange={setTextSize}
        textAlign={textAlign}
        onTextAlignChange={setTextAlign}
        onImageInsert={handleImageInsert}
        showGrid={showGrid}
        onGridToggle={() => setShowGrid(!showGrid)}
        canvases={canvases}
        currentCanvasId={currentCanvasId || ""}
        onCanvasSelect={setCurrentCanvasId}
        onCanvasCreate={handleCanvasCreate}
        onCanvasRename={handleCanvasRename}
        onCanvasDelete={handleCanvasDelete}
      />

      <CanvasArea
        activeTool={activeTool}
        strokeColor={strokeColor}
        fillColor={fillColor}
        textColor={textColor}
        zoom={zoom}
        penSize={penSize}
        penOpacity={penOpacity}
        penType={penType}
        eraserSize={eraserSize}
        textSize={textSize}
        textAlign={textAlign}
        showGrid={showGrid}
        onCanvasReady={handleCanvasReady}
        onShapeComplete={handleShapeComplete}
        onZoomChange={setZoom}
      />

      <RightSidebar
        zoom={zoom}
        onZoomChange={setZoom}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={canUndo}
        canRedo={canRedo}
        onExport={handleExport}
        onShare={handleShare}
        isConnected={collaboration.isConnected}
        userCount={collaboration.userCount}
        users={Array.from(collaboration.users.values())}
        currentUserId={collaboration.currentUserId}
        currentUserName={collaboration.currentUserName}
        currentUserColor={collaboration.currentUserColor}
        currentCanvasCode={currentCanvas?.code}
        activeTool={activeTool}
      />
    </div>
  );
}
