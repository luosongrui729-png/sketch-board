import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  FileText,
  Plus,
  ChevronDown,
  Pencil,
  Trash2,
  Download,
  Share2,
  Users,
  Wifi,
  WifiOff,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface TopBarProps {
  canvases: any[];
  currentCanvasId: string;
  onCanvasSelect: (id: string) => void;
  onCanvasCreate: () => void;
  onCanvasRename: (id: string, name: string) => void;
  onCanvasDelete: (id: string) => void;
  onExport: (format: string, options: any) => void;
  onShare: (code?: string) => void;
  isConnected: boolean;
  userCount: number;
  currentCanvasCode?: string;
}

export function TopBar(props: TopBarProps) {
  const currentCanvas = props.canvases.find(c => c.id === props.currentCanvasId);
  const [exportOpen, setExportOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [joinCode, setJoinCode] = useState("");
  const [exportFormat, setExportFormat] = useState<"png" | "pdf">("png");
  const [exportArea, setExportArea] = useState<"visible" | "full">("visible");
  const [exportResolution, setExportResolution] = useState<"1x" | "2x" | "4x">("1x");
  const [exportBg, setExportBg] = useState<"white" | "transparent">("white");

  const handleExport = () => {
    props.onExport(exportFormat, {
      area: exportArea,
      resolution: exportResolution,
      background: exportBg,
    });
    setExportOpen(false);
  };

  const handleJoinCanvas = () => {
    if (joinCode.length >= 6) {
      props.onShare(joinCode);
      setShareOpen(false);
      setJoinCode("");
    }
  };

  return (
    <div className="h-11 bg-[#1e1e1e] border-b border-[#2d2d2d] flex items-center gap-2 px-3" data-testid="top-bar">
      {/* Canvas Selector */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="gap-2 text-gray-300 hover:bg-white/5 hover:text-white transition-colors" data-testid="button-canvas-menu">
            <FileText className="w-4 h-4" />
            <span className="text-sm max-w-40 truncate font-medium">{currentCanvas?.name || "Canvas"}</span>
            <ChevronDown className="w-3.5 h-3.5" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-96 bg-[#252525] border-[#3a3a3a] shadow-2xl">
          <div className="p-2">
            <Button onClick={props.onCanvasCreate} className="w-full gap-2" size="sm" data-testid="button-create-canvas">
              <Plus className="w-4 h-4" />
              Create New Canvas
            </Button>
          </div>
          <DropdownMenuSeparator className="bg-[#2d2d2d]" />
          <div className="max-h-96 overflow-y-auto p-2 space-y-2">
            {props.canvases.map((canvas) => (
              <div
                key={canvas.id}
                className={cn(
                  "p-2 rounded cursor-pointer group hover:bg-white/5",
                  canvas.id === props.currentCanvasId && "bg-white/10"
                )}
                onClick={() => props.onCanvasSelect(canvas.id)}
                data-testid={`canvas-item-${canvas.id}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="text-sm text-white truncate">{canvas.name}</div>
                    <div className="text-xs text-gray-400 font-mono mt-0.5">Code: {canvas.code}</div>
                    <div className="text-xs text-gray-500 mt-0.5">
                      Modified {new Date(canvas.modifiedAt).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-white hover:bg-white/10"
                      onClick={(e) => {
                        e.stopPropagation();
                        const newName = prompt("Enter new name:", canvas.name);
                        if (newName) props.onCanvasRename(canvas.id, newName);
                      }}
                      data-testid={`button-rename-${canvas.id}`}
                    >
                      <Pencil className="w-3 h-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-red-400 hover:bg-white/10"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Delete "${canvas.name}"?`)) {
                          props.onCanvasDelete(canvas.id);
                        }
                      }}
                      data-testid={`button-delete-${canvas.id}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </DropdownMenuContent>
      </DropdownMenu>

      <Separator orientation="vertical" className="h-7 bg-[#2d2d2d]" />

      {/* Export Dialog */}
      <Dialog open={exportOpen} onOpenChange={setExportOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" className="gap-2 text-gray-300 hover:bg-white/5 hover:text-white transition-colors" data-testid="button-export">
            <Download className="w-4 h-4" />
            <span className="text-sm font-medium">Export</span>
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md bg-[#252525] border-[#3a3a3a] text-white shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Export Canvas</DialogTitle>
            <DialogDescription className="text-gray-400">
              Choose format and export options
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label className="text-sm text-white">Format</Label>
              <RadioGroup value={exportFormat} onValueChange={(v: any) => setExportFormat(v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="png" id="fmt-png" />
                  <Label htmlFor="fmt-png" className="text-sm text-gray-300 cursor-pointer">PNG Image</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="pdf" id="fmt-pdf" />
                  <Label htmlFor="fmt-pdf" className="text-sm text-gray-300 cursor-pointer">PDF Document</Label>
                </div>
              </RadioGroup>
            </div>
            {exportFormat === "png" && (
              <>
                <div className="space-y-2">
                  <Label className="text-sm text-white">Area</Label>
                  <RadioGroup value={exportArea} onValueChange={(v: any) => setExportArea(v)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="visible" id="area-vis" />
                      <Label htmlFor="area-vis" className="text-sm text-gray-300 cursor-pointer">Visible area only</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="full" id="area-full" />
                      <Label htmlFor="area-full" className="text-sm text-gray-300 cursor-pointer">Full canvas</Label>
                    </div>
                  </RadioGroup>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm text-white">Resolution</Label>
                  <RadioGroup value={exportResolution} onValueChange={(v: any) => setExportResolution(v)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="1x" id="res-1" />
                      <Label htmlFor="res-1" className="text-sm text-gray-300 cursor-pointer">1x (Standard)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="2x" id="res-2" />
                      <Label htmlFor="res-2" className="text-sm text-gray-300 cursor-pointer">2x (High-res)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="4x" id="res-4" />
                      <Label htmlFor="res-4" className="text-sm text-gray-300 cursor-pointer">4x (Ultra high-res)</Label>
                    </div>
                  </RadioGroup>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm text-white">Background</Label>
                  <RadioGroup value={exportBg} onValueChange={(v: any) => setExportBg(v)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="white" id="bg-w" />
                      <Label htmlFor="bg-w" className="text-sm text-gray-300 cursor-pointer">White</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="transparent" id="bg-t" />
                      <Label htmlFor="bg-t" className="text-sm text-gray-300 cursor-pointer">Transparent</Label>
                    </div>
                  </RadioGroup>
                </div>
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setExportOpen(false)} className="border-[#3E3F42] text-white hover:bg-white/10">
              Cancel
            </Button>
            <Button onClick={handleExport} data-testid="button-export-confirm">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Share Dialog */}
      <Dialog open={shareOpen} onOpenChange={setShareOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" className="gap-2 text-gray-300 hover:bg-white/5 hover:text-white transition-colors" data-testid="button-share">
            <Share2 className="w-4 h-4" />
            <span className="text-sm font-medium">Share</span>
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md bg-[#252525] border-[#3a3a3a] text-white shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Share Canvas</DialogTitle>
            <DialogDescription className="text-gray-400">
              Share this code for real-time collaboration
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {props.currentCanvasCode && (
              <div className="space-y-2">
                <Label className="text-sm text-white">Current Canvas Code</Label>
                <div className="flex gap-2">
                  <Input
                    value={props.currentCanvasCode}
                    readOnly
                    className="h-14 text-2xl font-mono tracking-widest text-center bg-[#1a1b1e] border-[#3E3F42] text-white"
                  />
                  <Button
                    onClick={() => {
                      navigator.clipboard.writeText(props.currentCanvasCode!);
                      console.log("Code copied!");
                    }}
                  >
                    Copy
                  </Button>
                </div>
              </div>
            )}
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-[#3E3F42]" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-[#2C2D30] px-2 text-gray-400">Or join another canvas</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-sm text-white">Enter Canvas Code</Label>
              <Input
                value={joinCode}
                onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                onKeyDown={(e) => e.key === "Enter" && handleJoinCanvas()}
                placeholder="ABC123"
                maxLength={8}
                className="h-14 text-2xl font-mono tracking-widest text-center bg-[#1a1b1e] border-[#3E3F42] text-white"
                data-testid="input-join-code"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShareOpen(false)} className="border-[#3E3F42] text-white hover:bg-white/10">
              Cancel
            </Button>
            <Button onClick={handleJoinCanvas} disabled={joinCode.length < 6} data-testid="button-join">
              Join Canvas
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="flex-1" />

      {/* User Presence */}
      <div className="flex items-center gap-2">
        <div
          className={cn(
            "flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium",
            props.isConnected ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20" : "bg-red-500/15 text-red-400 border border-red-500/20"
          )}
          data-testid="status-connection"
        >
          {props.isConnected ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
          <span>{props.isConnected ? "Connected" : "Disconnected"}</span>
        </div>
        {props.userCount > 1 && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-blue-500/15 text-blue-400 border border-blue-500/20" data-testid="status-users">
            <Users className="w-3 h-3" />
            <span>{props.userCount} users</span>
          </div>
        )}
      </div>
    </div>
  );
}
