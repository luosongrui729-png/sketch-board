import { Users, Wifi, WifiOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface User {
  id: string;
  name: string;
  color: string;
  tool: string;
}

interface UserPresenceProps {
  users: User[];
  isConnected: boolean;
}

export function UserPresence({ users, isConnected }: UserPresenceProps) {
  return (
    <div className="flex items-center gap-2">
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge
            variant={isConnected ? "default" : "secondary"}
            className="gap-1.5 h-8"
            data-testid="badge-connection-status"
          >
            {isConnected ? (
              <Wifi className="w-3 h-3" />
            ) : (
              <WifiOff className="w-3 h-3" />
            )}
            <span className="text-xs font-medium">
              {isConnected ? "Connected" : "Disconnected"}
            </span>
          </Badge>
        </TooltipTrigger>
        <TooltipContent side="bottom">
          <p className="text-xs">
            {isConnected
              ? "Real-time sync active"
              : "Reconnecting..."}
          </p>
        </TooltipContent>
      </Tooltip>

      {users.length > 0 && (
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge variant="outline" className="gap-1.5 h-8" data-testid="badge-user-count">
              <Users className="w-3 h-3" />
              <span className="text-xs font-medium">{users.length}</span>
            </Badge>
          </TooltipTrigger>
          <TooltipContent side="bottom" data-testid="tooltip-user-list">
            <div className="space-y-1">
              <p className="text-xs font-semibold mb-2">Active Users</p>
              {users.map((user) => (
                <div key={user.id} className="flex items-center gap-2">
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: user.color }}
                  />
                  <span className="text-xs">
                    {user.name} ({user.tool})
                  </span>
                </div>
              ))}
            </div>
          </TooltipContent>
        </Tooltip>
      )}
    </div>
  );
}
