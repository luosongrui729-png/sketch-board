import { useEffect, useRef, useState, useCallback } from "react";
import { Canvas, util } from "fabric";

function generateObjectId(): string {
  return `obj_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}

export interface User {
  id: string;
  name: string;
  color: string;
  tool: string;
  cursor?: { x: number; y: number };
}

interface CollaborationState {
  isConnected: boolean;
  users: Map<string, User>;
  userCount: number;
  currentUserId: string | null;
  currentUserColor: string | null;
  currentUserName: string | null;
}

interface QueuedAction {
  message: any;
  timestamp: number;
}

export function useCollaboration(canvasId: string | null, canvas: Canvas | null, currentTool: string = "select") {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const actionQueueRef = useRef<QueuedAction[]>([]);
  const [state, setState] = useState<CollaborationState>({
    isConnected: false,
    users: new Map(),
    userCount: 1,
    currentUserId: null,
    currentUserColor: null,
    currentUserName: null,
  });
  const ignoreNextEventRef = useRef(false);
  const lastTimestampsRef = useRef<Map<string, number>>(new Map());

  const send = useCallback((message: any, addTimestamp = true) => {
    const msg = addTimestamp ? { ...message, timestamp: Date.now() } : message;
    
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(msg));
      return true;
    } else {
      // Queue action if not connected
      actionQueueRef.current.push({ message: msg, timestamp: Date.now() });
      return false;
    }
  }, []);

  const flushQueue = useCallback(() => {
    // Send queued actions when reconnected
    const queue = actionQueueRef.current.sort((a, b) => a.timestamp - b.timestamp);
    queue.forEach(({ message }) => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify(message));
      }
    });
    actionQueueRef.current = [];
  }, []);

  const connectWebSocket = useCallback(() => {
    if (!canvasId) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("WebSocket connected");
      reconnectAttemptsRef.current = 0;
      setState(prev => ({ ...prev, isConnected: true }));
      
      // Get username from localStorage
      const username = localStorage.getItem("whiteboard_username") || "Anonymous";
      
      // Join the canvas with username (with timestamp)
      send({ type: "join-canvas", canvasId, username, tool: currentTool });
      
      // Flush queued actions
      flushQueue();
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        handleMessage(message);
      } catch (error) {
        console.error("WebSocket message error:", error);
      }
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
      setState(prev => ({ ...prev, isConnected: false }));
      
      // Auto-reconnect with exponential backoff
      const delay = Math.min(1000 * Math.pow(2, reconnectAttemptsRef.current), 30000);
      reconnectAttemptsRef.current++;
      
      reconnectTimeoutRef.current = setTimeout(() => {
        console.log(`Attempting to reconnect (attempt ${reconnectAttemptsRef.current})...`);
        connectWebSocket();
      }, delay);
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };
  }, [canvasId, currentTool, flushQueue]);

  // Connect to WebSocket
  useEffect(() => {
    connectWebSocket();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [canvasId]);

  const handleMessage = useCallback((message: any) => {
    switch (message.type) {
      case "canvas-state": {
        const users = new Map<string, User>();
        message.users.forEach((user: User) => {
          users.set(user.id, user);
        });
        setState(prev => ({
          ...prev,
          users,
          userCount: users.size + 1,
          currentUserId: message.userId,
          currentUserColor: message.color,
          currentUserName: message.name || localStorage.getItem("whiteboard_username") || "Anonymous",
        }));
        break;
      }

      case "user-joined": {
        setState(prev => {
          const users = new Map(prev.users);
          users.set(message.user.id, message.user);
          return {
            ...prev,
            users,
            userCount: users.size + 1,
          };
        });
        break;
      }

      case "user-left": {
        setState(prev => {
          const users = new Map(prev.users);
          users.delete(message.userId);
          return {
            ...prev,
            users,
            userCount: users.size + 1, // +1 for current user
          };
        });
        break;
      }

      case "cursor-move": {
        setState(prev => {
          const users = new Map(prev.users);
          const user = users.get(message.userId);
          if (user) {
            user.cursor = message.cursor;
            users.set(message.userId, user);
          }
          return { ...prev, users };
        });
        break;
      }

      case "tool-change": {
        setState(prev => {
          const users = new Map(prev.users);
          const user = users.get(message.userId);
          if (user) {
            user.tool = message.tool;
            users.set(message.userId, user);
          }
          return { ...prev, users };
        });
        break;
      }

      case "canvas-update": {
        if (canvas && message.data) {
          // Extract objectId for per-object timestamp tracking
          const objectId = message.data.objectId;
          const messageTimestamp = message.timestamp || 0;
          
          if (objectId) {
            // Check against the latest timestamp for this specific object
            const lastTimestamp = lastTimestampsRef.current.get(objectId) || 0;
            
            if (messageTimestamp >= lastTimestamp) {
              lastTimestampsRef.current.set(objectId, messageTimestamp);
              ignoreNextEventRef.current = true;
              
              if (message.action === "object-added") {
                // Rehydrate the JSON object into a Fabric object
                util.enlivenObjects([message.data]).then((objects: any[]) => {
                  if (objects && objects.length > 0) {
                    const obj = objects[0];
                    canvas.add(obj);
                    canvas.renderAll();
                    ignoreNextEventRef.current = false;
                  }
                });
              } else {
                ignoreNextEventRef.current = false;
              }
            }
          }
        }
        break;
      }

      case "object-modified": {
        if (canvas && message.object) {
          // Check timestamp per-object for last-action-wins
          const objectId = message.object.objectId;
          const messageTimestamp = message.timestamp || 0;
          const lastTimestamp = lastTimestampsRef.current.get(objectId) || 0;
          
          if (messageTimestamp >= lastTimestamp) {
            lastTimestampsRef.current.set(objectId, messageTimestamp);
            ignoreNextEventRef.current = true;
            const obj = canvas.getObjects().find((o: any) => o.objectId === objectId);
            if (obj) {
              obj.set(message.object);
              canvas.renderAll();
            }
            ignoreNextEventRef.current = false;
          }
        }
        break;
      }

      case "object-removed": {
        if (canvas && message.objectId) {
          // Check timestamp per-object for last-action-wins
          const objectId = message.objectId;
          const messageTimestamp = message.timestamp || 0;
          const lastTimestamp = lastTimestampsRef.current.get(objectId) || 0;
          
          if (messageTimestamp >= lastTimestamp) {
            lastTimestampsRef.current.set(objectId, messageTimestamp);
            ignoreNextEventRef.current = true;
            const obj = canvas.getObjects().find((o: any) => o.objectId === objectId);
            if (obj) {
              canvas.remove(obj);
              canvas.renderAll();
            }
            ignoreNextEventRef.current = false;
          }
        }
        break;
      }
    }
  }, [canvas]);

  // Send cursor position
  const sendCursor = useCallback((x: number, y: number) => {
    send({ type: "cursor-move", cursor: { x, y } });
  }, [send]);

  // Send tool change
  const sendToolChange = useCallback((tool: string) => {
    send({ type: "tool-change", tool });
  }, [send]);

  // Broadcast tool changes
  useEffect(() => {
    if (state.isConnected) {
      sendToolChange(currentTool);
    }
  }, [currentTool, state.isConnected, sendToolChange]);

  // Send canvas update
  const sendCanvasUpdate = useCallback((action: string, data: any) => {
    if (!ignoreNextEventRef.current) {
      send({ type: "canvas-update", action, data });
    }
    ignoreNextEventRef.current = false;
  }, [send]);

  // Send object modified
  const sendObjectModified = useCallback((object: any) => {
    if (!ignoreNextEventRef.current) {
      send({ type: "object-modified", object });
    }
    ignoreNextEventRef.current = false;
  }, [send]);

  // Send object removed
  const sendObjectRemoved = useCallback((objectId: string) => {
    if (!ignoreNextEventRef.current) {
      send({ type: "object-removed", objectId });
    }
    ignoreNextEventRef.current = false;
  }, [send]);

  // Helper to assign stable IDs to objects
  const assignObjectId = useCallback((obj: any) => {
    if (!obj.objectId) {
      obj.objectId = generateObjectId();
    }
    return obj.objectId;
  }, []);

  return {
    ...state,
    sendCursor,
    sendToolChange,
    sendCanvasUpdate,
    sendObjectModified,
    sendObjectRemoved,
    assignObjectId,
  };
}
