import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Circle,
  Square,
  Triangle,
  Minus,
  MoveRight,
  Pentagon,
  Hexagon,
  Star,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface PenOptions {
  size: number;
  opacity: number;
  type: "standard" | "marker" | "highlighter";
}

interface ShapeType {
  id: string;
  label: string;
  icon: React.ReactNode;
}

const SHAPE_TYPES: ShapeType[] = [
  { id: "rectangle", label: "Rectangle", icon: <Square className="w-5 h-5" /> },
  { id: "circle", label: "Circle", icon: <Circle className="w-5 h-5" /> },
  { id: "triangle", label: "Triangle", icon: <Triangle className="w-5 h-5" /> },
  { id: "line", label: "Line", icon: <Minus className="w-5 h-5" /> },
  { id: "arrow", label: "Arrow", icon: <MoveRight className="w-5 h-5" /> },
  { id: "pentagon", label: "Pentagon", icon: <Pentagon className="w-5 h-5" /> },
  { id: "hexagon", label: "Hexagon", icon: <Hexagon className="w-5 h-5" /> },
  { id: "star", label: "Star", icon: <Star className="w-5 h-5" /> },
];

interface ToolOptionsPanelProps {
  tool: string;
  penOptions?: PenOptions;
  selectedShape?: string;
  onPenOptionsChange?: (options: PenOptions) => void;
  onShapeSelect?: (shapeId: string) => void;
}

export function ToolOptionsPanel({
  tool,
  penOptions,
  selectedShape,
  onPenOptionsChange,
  onShapeSelect,
}: ToolOptionsPanelProps) {
  if (tool === "pen" && penOptions && onPenOptionsChange) {
    return (
      <Card className="p-4 space-y-4 w-64" data-testid="panel-pen-options">
        <div className="space-y-2">
          <Label className="text-xs font-semibold">Brush Size</Label>
          <Slider
            value={[penOptions.size]}
            onValueChange={([size]) =>
              onPenOptionsChange({ ...penOptions, size })
            }
            min={2}
            max={20}
            step={1}
            data-testid="slider-pen-size"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>2px</span>
            <span>{penOptions.size}px</span>
            <span>20px</span>
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-xs font-semibold">Opacity</Label>
          <Slider
            value={[penOptions.opacity]}
            onValueChange={([opacity]) =>
              onPenOptionsChange({ ...penOptions, opacity })
            }
            min={0}
            max={100}
            step={1}
            data-testid="slider-pen-opacity"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0%</span>
            <span>{penOptions.opacity}%</span>
            <span>100%</span>
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-xs font-semibold">Pen Type</Label>
          <div className="grid grid-cols-3 gap-1">
            {["standard", "marker", "highlighter"].map((type) => (
              <Button
                key={type}
                variant="outline"
                size="sm"
                onClick={() =>
                  onPenOptionsChange({
                    ...penOptions,
                    type: type as PenOptions["type"],
                  })
                }
                className={cn(
                  "capitalize",
                  penOptions.type === type && "bg-accent"
                )}
                data-testid={`button-pen-type-${type}`}
              >
                {type}
              </Button>
            ))}
          </div>
        </div>
      </Card>
    );
  }

  if (tool === "shapes" && onShapeSelect) {
    return (
      <Card className="p-4 space-y-3 w-80" data-testid="panel-shape-options">
        <Label className="text-xs font-semibold">Select Shape</Label>
        <div className="grid grid-cols-4 gap-2">
          {SHAPE_TYPES.map((shape) => (
            <Button
              key={shape.id}
              variant="outline"
              size="icon"
              className={cn(
                "w-12 h-12",
                selectedShape === shape.id && "bg-accent"
              )}
              onClick={() => onShapeSelect(shape.id)}
              data-testid={`button-shape-${shape.id}`}
            >
              {shape.icon}
            </Button>
          ))}
        </div>
      </Card>
    );
  }

  return null;
}
